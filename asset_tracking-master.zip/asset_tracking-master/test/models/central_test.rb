require 'test_helper'

class CentralTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
