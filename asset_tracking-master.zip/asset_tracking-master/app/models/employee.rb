class Employee < ApplicationRecord
	belongs_to :beacon
end
