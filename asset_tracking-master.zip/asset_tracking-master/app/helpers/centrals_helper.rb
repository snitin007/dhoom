module CentralsHelper
end
