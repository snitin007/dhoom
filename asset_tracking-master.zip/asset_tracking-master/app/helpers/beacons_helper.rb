module BeaconsHelper
end
